import cv2 
from ultralytics import YOLO
from datetime import datetime, time as datetime_time
import time
import requests
import mysql.connector
import os
import io

#IMPORTANT TO CHANGE เปลี่ยนตัวแปร สำหรับการรันชุดคำสั่งนี้
Line_Token='VeO8f8U5ryobRx2WXNAyK2Gps8TjI9U78tVP4x6D0TB'
username = 'admin'
password = 'ptf@1234'
ip_camera='192.168.1.64' 
frame_camera = (1920,1080)
location = 2 
            # location_name = 'อสร.'
            # location_name = 'ห้องพัสดุ'
            # location_name = 'ไม่ระบุ'
file = '15.mp4' #video.mp4
c =[0] #model.names
l = 0  #คลาสที่อยากให้ตรวจจับ
capture = cv2.VideoCapture(file) #if PC_camera --> 0 if hikvision_camera --> rtsp

#Load a model
model = YOLO("face.pt")  # load an model
#///////////////////////////////////////////////////////////////////////////
ip = ip_camera+':554' #rstp protocal
#'192.168.1.64:554'
#///////////////////////////////////////////////////////////////////////////
crop_img_path = 'app/images/img_no_hat_crop_'
#///////////////////////////////////////////////////////////////////////////
#make folder for storing images and videos
os.makedirs('app', exist_ok=True)
os.makedirs('app/images', exist_ok=True)
#///////////////////////////////////////////////////////////////////////////
#time
timenow = datetime.now().strftime('%d-%m-%Y %H:%M')
#///////////////////////////////////////////////////////////////////////////
#Set parameters for Main function
count = 0 #for counter on timer (10 count = 1 sec)
ind = 0 #increment number for saving img 
j= 0# for each loop
no_hat = 0 #for counter on NO-Hard-Hat
countforout = 0 #for saving video and start recording 
detected_objects = [] #for saving class on detect in specific frame
#///////////////////////////////////////////////////////////////////////////
#parameter for adding text on frame 
font_type = cv2.FONT_HERSHEY_PLAIN  
font_scale = 1.2
color = (0, 255, 255)  # Yellow color in BGR format
thickness = 1
#///////////////////////////////////////////////////////////////////////////
#parameter for saving video
# (1920,1080) for matching frame on Hikvision Camera
        # out = cv2.VideoWriter((vid_path+str(countforout)+'.avi'), fourcc, 10.0, frame_camera)  # Change the output resolution if needed
#///////////////////////////////////////////////////////////////////////////
rtsp = f'rtsp://{username}:{password}@{ip}/Streaming/Channels/101/?transportmode=unicast' # Defualt IP CAMERA Hikvision
img_sent = False
found =0
def SentLatestImgFromDatabase():
    # Connect to the database
    connection = mysql.connector.connect(
        **db_config
    )

    cursor = connection.cursor()

    # Retrieve the latest BLOB image from the database based on the Date column
    query = """
    SELECT imagefile
    FROM image
    ORDER BY Date DESC
    LIMIT 1
    """
    cursor.execute(query)
    result = cursor.fetchone()

    match location:
        case 1:
            location_name = 'อสร.'
        case 2:
            location_name = 'โกดัง'
        case _:
            location_name = 'ไม่ระบุ'

    msg = f'ตรวจจับบุคคล\nณ {location_name}\nวันที่ {timenow} น.'
    # Ensure the result is not None
    if result and result[0]:
        img_blob = result[0]

        # Save the BLOB to a temporary file
        with open('temp_image.jpg', 'wb') as temp_file:
            temp_file.write(img_blob)

        # Prepare to send the image via LINE Notify
        url = 'https://notify-api.line.me/api/notify'
        token = Line_Token
        headers = {'Authorization': 'Bearer ' + token}
        session = requests.Session()

        # Send the image using the temporary file
        with open('temp_image.jpg', 'rb') as img_file:
            file = {'imageFile': img_file}
            data = {'message': msg}
            req = session.post(url, headers=headers, files=file, data=data)
        
        # Print the response status code
        print(req.status_code)
    # Clean up the database connection
    cursor.close()
    connection.close()
#//////////////////////////////////////////////////////////////////////////
# mysql database
db_config = {
    'host': 'localhost',
    'port': 3306 ,
    'user': 'root',
    'password': '',
    'database': 'mydb'
}

def insert_image_database(classes,image_path, db_config):
        # Connect to the database
        cnx = mysql.connector.connect(**db_config)
        cursor = cnx.cursor()

        # Read the image file
        with open(image_path, 'rb') as f:
            image_data = f.read()

        # Insert the image data into the database
        insert_query = "INSERT INTO image (class, location, Date, imagefile) VALUES (%s, %s,NOW(), %s)"
        data = (classes,location,image_data,)
        cursor.execute(insert_query, data)
        cnx.commit()
        print("Image inserted successfully!")
        cursor.close()
        cnx.close()

def clearAll_Img_Database():
    # Connect to the database
    connection = mysql.connector.connect(
    **db_config
    )
    
    cursor = connection.cursor()
    
    try:
        # Delete all records from the image table
        delete_query = "DELETE FROM image"
        cursor.execute(delete_query)
        connection.commit()
        print(f"{cursor.rowcount} records deleted from the image table.")

        # Remove all image files in the app/images directory
        image_dir = 'app/images/'
        for filename in os.listdir(image_dir):
            file_path = os.path.join(image_dir, filename)
            try:
                if os.path.isfile(file_path):
                    os.unlink(file_path)
                    print(f"Deleted file: {file_path}")
            except Exception as e:
                print(f"Failed to delete {file_path}. Reason: {e}")

    except mysql.connector.Error as err:
        print(f"Error: {err}")
        connection.rollback()
    finally:
        cursor.close()
        connection.close()
# ////////////////////////////////////////////////////////////////////////////////////////////


#################/////////////////////////////MAIN_Function///////////////////////////////////////##############
# Main Loop
while True:
    #กำหนดวันที่จะให้ตรวจจับ
    # if not is_within_time_range():
    #     print("Out of monitoring time range. Waiting...")
    #     time.sleep(60)  # Wait for 1 minute before checking again
    #     continue

    ret, frame = capture.read()

    if ret:
        result = model.track(frame, classes=c, conf=0.5)  # detect Face

        # Storing detected classes and other details
        cls = result[0].boxes.cls.numpy()
        conf = result[0].boxes.conf.numpy()
        xyxy = result[0].boxes.xyxy.numpy()
        detected_objects.clear()

        # If detected objects exist in the frame
        if len(cls) != 0:
            for box, score, label in zip(xyxy, conf, cls):
                x1, y1, x2, y2 = int(box[0]), int(box[1]), int(box[2]), int(box[3])
                conf_score = int(score * 100)
                cls_name = result[0].names[label]

                # If it detected and an image hasn't been sent yet
                if label == l and not img_sent:
                    print('Found!')
                    found += 1
                    crop = frame[y1:(y2*3 - y1*2), (x1 - round(x1/4)):(x2 + round(x1/4))]
                    crop_img = crop_img_path + str(ind) + '.jpg'
                    cv2.imwrite(crop_img, crop)
                    # Send the cropped image to Line Notify
                    insert_image_database(model.names[l],crop_img,db_config)
                    SentLatestImgFromDatabase()
                    ind += 1
                    img_sent = True  
                    # Reset image index if it exceeds 50
                    if ind >= 50:
                        ind = 0
                        clearAll_Img_Database()
        if (found == 3):
            img_sent = False
            found = 0
        # Display the result on the frame
        frame = result[0].plot()
        cv2.imshow('Streaming', frame)
        # Exit on 'q' key
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break
    else:
        break

capture.release()
cv2.destroyAllWindows()