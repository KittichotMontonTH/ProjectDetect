วิธีการติดตั้ง
1.แตกไฟล์
2.เข้าโปรแกรม Visual Studio Code 
3.ไปที่ File--> Open Folder
4.เลือก Folder app
5.ตรงส่วนของ แว่นขยาย ให้เลือก Show and Run Commands หรือ Ctrl+Shift+P
6.เลือก Python Create Environment
7.เลือก Venv
8.เลือก version Python ที่ติดตั้งไว้แนะนำ (สามารถดาวน์โหลด Python จาก Microsoft Store)
9.เลือก requirements.text แล้วกด ok
10.รอโปรแกรม สร้าง Venv เสร็จ
11.Run

แนะนำเปลี่ยน Token ของ Line Notify และ IP ของ กล้อง Hikvision ก่อน Run